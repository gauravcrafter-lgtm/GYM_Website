console.log("hello")
setTimeout(()=>{
    console.log("hba");
},3000);
console.log("jee");